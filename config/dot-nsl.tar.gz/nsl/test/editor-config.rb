Rails.configuration.ldap_admin_username = "uid=admin,ou=system"
Rails.configuration.ldap_admin_password = "secret"
Rails.configuration.ldap_base = "dc=com"
Rails.configuration.ldap_host = 'localhost'
Rails.configuration.ldap_port = 10389
Rails.configuration.ldap_users = "ou=users,dc=example,dc=com"
Rails.configuration.ldap_groups = "ou=groups,dc=example,dc=com"

#Rails.configuration.services_clientside_root_url = 'http://nsl-services.dev/'
#Rails.configuration.nsl_services = 'http://nsl-services.dev/'
#
# When running the mock services under pow with the host "nsl-services.dev" 
# it was taking > 6 seconds for the service call to return inside the Rails reference model.
#
# Here it took nearly 11 seconds:
#
# 2015-05-29 13:59:14.879 [meh] set_citation! (pid:83864)
# 2015-05-29 13:59:14.879 [meh] http://nsl-services.dev/api/makeCitation/reference/156436017 (pid:83864)
# 2015-05-29 13:59:14.879 [meh] about to call the service (pid:83864)
# 2015-05-29 13:59:25.855 [meh] back from the service call (pid:83864)
#
# Running the mock services on localhost with a port reduced the delay to 
#
# Here it took ~0.002 seconds:
#
#2015-05-29 14:06:20.793 [meh] set_citation! (pid:84293)
#2015-05-29 14:06:20.794 [meh] http://127.0.0.1:9090/api/makeCitation/reference/156436017 (pid:84293)
#2015-05-29 14:06:20.794 [meh] about to call the service (pid:84293)
#2015-05-29 14:06:20.796 [meh] back from the service call (pid:84293)
#
Rails.configuration.services_clientside_root_url = 'http://127.0.0.1:9090/'
Rails.configuration.nsl_services = 'http://127.0.0.1:9090/'
Rails.configuration.nsl_links = 'http://biodiversity.org.au/nsl/services/'

if ENV['SESSION_KEY_TAG'].nil?
  Rails.configuration.session_key_tag = 'local_test'
else
  Rails.configuration.session_key_tag = ENV['SESSION_KEY_TAG']
end

