environments {
    development {
        dataSource_nsl {
          username = "gregc"
          password = "gregc"
          url = "jdbc:postgresql://localhost:5432/nsl"
        }
    }
    test {
        dataSource_nsl {
          username = "gregc"
          password = "gregc"
          url = "jdbc:postgresql://localhost:5432/nsl-test"
        }
    }
    production {
        dataSource_nsl {
          username = "gregc"
          password = "gregc"
          url = "jdbc:postgresql://localhost:5432/nsl"
        }
    }
}
