
Rails.configuration.ldap_admin_username = "uid=admin,ou=system"
Rails.configuration.ldap_admin_password = "secret"
Rails.configuration.ldap_base = "dc=com"
Rails.configuration.ldap_host = 'localhost'
Rails.configuration.ldap_port = 10389
Rails.configuration.ldap_users = "ou=users,dc=example,dc=com"
Rails.configuration.ldap_groups = "ou=groups,dc=example,dc=com"

Rails.configuration.services_clientside_root_url = 'http://localhost:8080/nsl/services/'
Rails.configuration.nsl_services = 'http://localhost:8080/nsl/services/'
Rails.configuration.nsl_links = 'http://biodiversity.org.au/nsl/services/'

if ENV['SESSION_KEY_TAG'].nil?
    Rails.configuration.session_key_tag = 'dev'
else
    Rails.configuration.session_key_tag = ENV['SESSION_KEY_TAG']
end


Ned::Application.config.middleware.use ExceptionNotification::Rack,
  email: {
    email_prefix: "[prefix]",
    sender_address: %{"nsl-development" <nsl-development@example.com>},
    exception_recipients: %w{gregbclarke@gmail.com}
  }

