Rails.configuration.relative_url_root = '/test-nsl-editor'
